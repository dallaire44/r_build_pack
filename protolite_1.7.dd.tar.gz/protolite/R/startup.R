.onLoad <- function(lib, pkg){
  R_start_protobuf()
}
